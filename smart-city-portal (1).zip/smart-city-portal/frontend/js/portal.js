const GUARDED = ['submit', 'mine', 'admin'];
function show(id) {
  if (!document.getElementById(id) || id === 'toast') id = 'login';
  if (GUARDED.includes(id) && !session) { toast('Please log in first'); id = 'login'; }
  if (session && ['login', 'register'].includes(id)) id = session.user.role === 'admin' ? 'admin' : 'submit';
  document.querySelectorAll('.view').forEach(v => v.classList.toggle('active', v.id === id));
  history.replaceState(null, '', '#' + id);
  if (id === 'submit') loadCategories();
  if (id === 'mine') loadMine();
  if (id === 'admin') loadAdmin();
}
async function doRegister(e) {
  e.preventDefault();
  try {
    setSession(await api('/register', 'POST', { name: $('rName').value, email: $('rEmail').value,
      phone: $('rPhone').value, password: $('rPass').value }));
    toast('Registration successful'); show('submit');
  } catch (err) { toast(err.message); }
}
async function doLogin(e) {
  e.preventDefault();
  try {
    setSession(await api('/login', 'POST', { email: $('lEmail').value, password: $('lPass').value }));
    toast('Welcome ' + session.user.name);
    show(session.user.role === 'admin' ? 'admin' : (sessionStorage.getItem('pendingCat') ? 'submit' : 'mine'));
  } catch (err) { toast(err.message); }
}
async function loadCategories() {
  try {
    const cats = await api('/categories');
    $('cCat').innerHTML = '<option value="">-- Select category --</option>' +
      cats.map(c => `<option value="${c.id}">${esc(c.name)}</option>`).join('');
    const want = sessionStorage.getItem('pendingCat');   // set by the category pages
    if (want) { const m = cats.find(c => c.name === want); if (m) $('cCat').value = m.id;
      sessionStorage.removeItem('pendingCat'); }
  } catch (err) { toast(err.message); }
}
async function doSubmit(e) {
  e.preventDefault();
  try {
    const r = await api('/complaints', 'POST', { category_id: +$('cCat').value, title: $('cTitle').value,
      description: $('cDesc').value, location: $('cLoc').value, priority: $('cPri').value });
    e.target.reset();
    alert('Complaint submitted!\nYour Complaint ID: ' + r.complaint_id + '\nKeep it to track the status.');
    show('mine');
  } catch (err) { toast(err.message); }
}
async function loadMine() {
  try {
    const list = await api('/complaints/mine');
    $('mineList').innerHTML = list.length ? list.map(c => card(c)).join('') : '<p class="muted">No complaints yet.</p>';
  } catch (err) { toast(err.message); }
}
async function loadAdmin() {
  try {
    const s = await api('/admin/stats');
    $('stats').innerHTML = Object.entries(s).map(([k, v]) => `<div class="stat"><b>${v}</b>${k}</div>`).join('');
    const list = await api('/admin/complaints' + ($('fStatus').value ? '?status=' + encodeURIComponent($('fStatus').value) : ''));
    $('adminRows').innerHTML = list.map(c => `<tr>
      <td>${esc(c.complaint_id)}</td><td>${esc(c.category)}</td>
      <td><b>${esc(c.title)}</b><br><span class="muted">${esc(c.location)}</span></td>
      <td>${esc(c.citizen)}</td><td class="${c.priority}">${c.priority}</td>
      <td><span class="badge ${cls(c.status)}">${c.status}</span></td>
      <td><div class="upd">
        <select id="st-${c.complaint_id}">${['Pending','In Progress','Resolved','Rejected']
          .map(x => `<option ${x === c.status ? 'selected' : ''}>${x}</option>`).join('')}</select>
        <input id="rm-${c.complaint_id}" placeholder="Remark for citizen">
        <button onclick="updateStatus('${c.complaint_id}')">Update</button></div></td></tr>`).join('')
      || '<tr><td colspan="7">No complaints found.</td></tr>';
  } catch (err) { toast(err.message); }
}
async function updateStatus(id) {
  try {
    await api('/admin/complaints/' + id, 'PUT', { status: $('st-' + id).value, remark: $('rm-' + id).value });
    toast('Status updated'); loadAdmin();
  } catch (err) { toast(err.message); }
}
renderNav('portal');
window.addEventListener('hashchange', () => show(location.hash.slice(1)));
show(location.hash.slice(1) || 'login');
