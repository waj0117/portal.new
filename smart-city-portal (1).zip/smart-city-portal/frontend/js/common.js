const API = 'http://localhost:3000/api'; // backend URL
let session = JSON.parse(localStorage.getItem('scp') || 'null');

async function api(path, method = 'GET', body) {
  const res = await fetch(API + path, {
    method,
    headers: { 'Content-Type': 'application/json',
      ...(session ? { Authorization: 'Bearer ' + session.token } : {}) },
    body: body ? JSON.stringify(body) : undefined
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Something went wrong');
  return data;
}
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const cls = s => s.replace(' ', '-');
function toast(msg) { const t = $('toast'); if (!t) return alert(msg);
  t.textContent = msg; t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 2800); }

// name = exact category name stored in the database (backend/database/schema.sql)
const CATS = {
  roads: { name: 'Damaged Roads', short: 'Damaged Roads', icon: 'road', color: '#f59e0b',
    blurb: 'Potholes, cracks and broken pavements.',
    headline: 'Potholes and broken roads, fixed faster.',
    intro: 'Report potholes, cracks, sunken patches and broken footpaths so the roads department can inspect and repair them.',
    covers: ['Potholes and craters', 'Cracked or sunken road surface', 'Broken footpaths and kerbs', 'Open or missing manhole covers'],
    dept: 'Roads & Highways Department', eta: '3 to 7 days' },
  water: { name: 'Water Shortage', short: 'Water Shortage', icon: 'water', color: '#2a9df4',
    blurb: 'No supply, low pressure or leaking pipes.',
    headline: 'No water? Let the city know.',
    intro: 'Tell us where the supply has stopped or turned unreliable. Reports from your street help the water board find the fault quickly.',
    covers: ['No supply in your area', 'Low pressure or irregular timing', 'Leaking or burst pipes', 'Dirty or contaminated water'],
    dept: 'Water Supply Board', eta: '1 to 3 days' },
  garbage: { name: 'Garbage Overflow', short: 'Garbage Overflow', icon: 'garbage', color: '#34a874',
    blurb: 'Overflowing bins and uncollected waste.',
    headline: 'Clean streets start with one report.',
    intro: 'Overflowing bins and waste that has not been collected spread disease and smell. Report it and the sanitation team will schedule a pickup.',
    covers: ['Overflowing public bins', 'Waste not collected for days', 'Illegal dumping', 'Hazardous or dead-animal waste'],
    dept: 'Sanitation Department', eta: '24 to 48 hours' },
  drainage: { name: 'Drainage Blockage', short: 'Drainage Blockage', icon: 'drainage', color: '#3d8f8c',
    blurb: 'Blocked drains, sewage and waterlogging.',
    headline: 'Keep water moving, keep streets dry.',
    intro: 'Blocked drains cause waterlogging, bad smells and mosquito breeding. Report the spot and the drainage board will send a crew to clear it.',
    covers: ['Blocked or overflowing drains', 'Sewage on the road', 'Waterlogging after rain', 'Broken drain covers'],
    dept: 'Drainage & Sewerage Board', eta: '2 to 5 days' },
  streetlight: { name: 'Streetlight Not Working', short: 'Streetlights', icon: 'streetlight', color: '#e8a500',
    blurb: 'Dark, flickering or damaged street lamps.',
    headline: 'Light up the dark stretches.',
    intro: 'Dark roads are unsafe roads. Tell us which lamp is out or flickering, with the nearest landmark, and the electrical team will fix it.',
    covers: ['Lamps that do not turn on', 'Flickering or dim lights', 'Damaged poles or hanging wires', 'Roads with no lighting at all'],
    dept: 'Electricity & Street Lighting', eta: '1 to 3 days' },
  other: { name: 'Other', short: 'Raise your own', icon: 'other', color: '#8b5cf6',
    blurb: 'Problem not listed? Describe it in your own words.',
    headline: 'Something else? Raise your own.',
    intro: 'If your problem is not in the list, describe it yourself. Stray animals, encroachment, noise or damaged public property all reach the right team.',
    covers: ['Any civic issue not listed', 'Safety hazards in your area', 'Damaged public property', 'Suggestions to improve your area'],
    dept: 'Routed by city administrators', eta: 'Depends on the issue' }
};

function setSession(s) {
  session = s; s ? localStorage.setItem('scp', JSON.stringify(s)) : localStorage.removeItem('scp');
  renderNav(window.PAGE);
}
async function logout() {
  try { await api('/logout', 'POST'); } catch {}
  setSession(null); location.href = 'home.html';
}
// Header + menu. The link to the page you are already on is left out.
function renderNav(cur) {
  window.PAGE = cur;
  let h = document.querySelector('header.top');
  if (!h) { document.body.insertAdjacentHTML('afterbegin',
    '<header class="top"><a class="brand" href="home.html"><img src="assets/logo.svg" alt="">Smart City Portal</a><nav id="nav"></nav></header>');
    h = document.querySelector('header.top'); }
  const a = (label, href, c = '') => `<a href="${href}" class="${c}">${label}</a>`;
  let n = '';
  if (cur !== 'home') n += a('Home', 'home.html');
  if (cur !== 'track') n += a('Track', 'track.html');
  if (!session) n += a('Login', 'portal.html#login') + a('Register', 'portal.html#register', 'cta');
  else {
    if (session.user.role === 'admin') n += a('Dashboard', 'portal.html#admin');
    else n += a('New Complaint', 'portal.html#submit') + a('My Complaints', 'portal.html#mine');
    n += `<button onclick="logout()">Logout (${esc(session.user.name.split(' ')[0])})</button>`;
  }
  h.querySelector('nav').innerHTML = n;
}
// Start a complaint from a category page: remember the category, then go to the form
function startComplaint(key) {
  sessionStorage.setItem('pendingCat', CATS[key].name);
  location.href = 'portal.html#submit';
}
const card = (c, btn = true) => `<div class="item">
  <div class="row"><b>${esc(c.complaint_id)} — ${esc(c.title)}</b>
  <span class="badge ${cls(c.status)}">${c.status}</span></div>
  <p class="muted">${esc(c.category)} • ${esc(c.location)} • Priority: <span class="${c.priority}">${c.priority}</span></p>
  <p>${esc(c.description)}</p>
  <p class="muted">Filed: ${c.created_at} • Updated: ${c.updated_at}</p>
  ${btn ? `<a class="btn ghost" style="margin-top:10px" href="track.html?id=${encodeURIComponent(c.complaint_id)}">View timeline</a>` : ''}</div>`;
