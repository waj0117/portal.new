require('dotenv').config();
const express = require('express');
const mysql = require('mysql2/promise');
const crypto = require('crypto');

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: +(process.env.DB_PORT || 3306),
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME || 'smartcity',
  dateStrings: true
});
// q('SELECT ... WHERE id=?', [5]) -> rows (SELECT) or result info (INSERT/UPDATE)
const q = async (text, params = [], conn = pool) => (await conn.execute(text, params))[0];

const hash = (pw, salt = crypto.randomBytes(8).toString('hex')) =>
  salt + ':' + crypto.scryptSync(pw, salt, 32).toString('hex');
const verify = (pw, stored) => hash(pw, stored.split(':')[0]) === stored;

const app = express();
app.use(express.json());
app.use((req, res, next) => {            // allow the separate frontend to call this API
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.header('Access-Control-Allow-Methods', 'GET,POST,PUT,OPTIONS');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

const wrap = fn => (req, res) => fn(req, res).catch(e => {
  console.error(e); res.status(500).json({ error: 'Server error' });
});
const auth = role => async (req, res, next) => {
  try {
    const token = (req.headers.authorization || '').replace('Bearer ', '');
    const rows = await q(`SELECT u.id,u.name,u.email,u.role FROM sessions s
      JOIN users u ON u.id=s.user_id WHERE s.token=?`, [token]);
    if (!rows[0]) return res.status(401).json({ error: 'Please log in' });
    if (role && rows[0].role !== role) return res.status(403).json({ error: 'Not allowed' });
    req.user = rows[0]; next();
  } catch (e) { res.status(500).json({ error: 'Server error' }); }
};
const login = async user => {
  const token = crypto.randomBytes(24).toString('hex');
  await q('INSERT INTO sessions(token,user_id) VALUES (?,?)', [token, user.id]);
  return { token, user: { id: user.id, name: user.name, email: user.email, role: user.role } };
};

app.post('/api/register', wrap(async (req, res) => {
  const { name, email, phone, password } = req.body;
  if (!name || !email || !password || password.length < 6)
    return res.status(400).json({ error: 'Name, email and a 6+ character password are required' });
  try {
    const r = await q('INSERT INTO users(name,email,phone,password) VALUES (?,?,?,?)',
      [name.trim(), email.trim().toLowerCase(), phone || null, hash(password)]);
    res.json(await login({ id: r.insertId, name: name.trim(), email: email.trim().toLowerCase(), role: 'citizen' }));
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'Email already registered' });
    throw e;
  }
}));

app.post('/api/login', wrap(async (req, res) => {
  const rows = await q('SELECT * FROM users WHERE email=?', [(req.body.email || '').trim().toLowerCase()]);
  if (!rows[0] || !verify(req.body.password || '', rows[0].password))
    return res.status(401).json({ error: 'Invalid email or password' });
  res.json(await login(rows[0]));
}));

app.post('/api/logout', auth(), wrap(async (req, res) => {
  await q('DELETE FROM sessions WHERE token=?', [req.headers.authorization.replace('Bearer ', '')]);
  res.json({ ok: true });
}));

app.get('/api/categories', wrap(async (_, res) => res.json(await q('SELECT * FROM categories ORDER BY id'))));

const SELECT = `SELECT c.complaint_id,c.title,c.description,c.location,c.priority,c.status,
  DATE_FORMAT(c.created_at,'%Y-%m-%d %H:%i') AS created_at,
  DATE_FORMAT(c.updated_at,'%Y-%m-%d %H:%i') AS updated_at,
  cat.name AS category,u.name AS citizen
  FROM complaints c JOIN categories cat ON cat.id=c.category_id JOIN users u ON u.id=c.user_id`;

app.post('/api/complaints', auth('citizen'), wrap(async (req, res) => {
  const { category_id, title, description, location, priority } = req.body;
  if (!category_id || !title || !description || !location)
    return res.status(400).json({ error: 'All fields are required' });
  const r = await q(`INSERT INTO complaints(user_id,category_id,title,description,location,priority)
    VALUES (?,?,?,?,?,?)`, [req.user.id, category_id, title, description, location,
    ['Low', 'Medium', 'High'].includes(priority) ? priority : 'Medium']);
  // Complaint ID such as SCP-2026-00001
  await q("UPDATE complaints SET complaint_id=CONCAT('SCP-',YEAR(created_at),'-',LPAD(id,5,'0')) WHERE id=?", [r.insertId]);
  const rows = await q('SELECT complaint_id FROM complaints WHERE id=?', [r.insertId]);
  res.json(rows[0]);
}));

app.get('/api/complaints/mine', auth(), wrap(async (req, res) =>
  res.json(await q(SELECT + ' WHERE c.user_id=? ORDER BY c.id DESC', [req.user.id]))));

app.get('/api/track/:cid', wrap(async (req, res) => {
  const rows = await q(SELECT + ' WHERE c.complaint_id=?', [req.params.cid.trim().toUpperCase()]);
  if (!rows[0]) return res.status(404).json({ error: 'Complaint ID not found' });
  const history = await q(`SELECT h.status,h.remark,DATE_FORMAT(h.changed_at,'%Y-%m-%d %H:%i') AS changed_at
    FROM status_history h JOIN complaints c ON c.id=h.complaint_id
    WHERE c.complaint_id=? ORDER BY h.id`, [rows[0].complaint_id]);
  res.json({ ...rows[0], history });
}));

app.get('/api/admin/complaints', auth('admin'), wrap(async (req, res) => {
  const { status } = req.query;
  const order = ` ORDER BY CASE c.status WHEN 'Pending' THEN 0 WHEN 'In Progress' THEN 1 ELSE 2 END,
    CASE c.priority WHEN 'High' THEN 0 WHEN 'Medium' THEN 1 ELSE 2 END, c.id DESC`;
  res.json(status ? await q(SELECT + ' WHERE c.status=?' + order, [status]) : await q(SELECT + order));
}));

app.get('/api/admin/stats', auth('admin'), wrap(async (_, res) => {
  const rows = await q('SELECT status, COUNT(*) AS n FROM complaints GROUP BY status');
  const s = { Total: 0, Pending: 0, 'In Progress': 0, Resolved: 0, Rejected: 0 };
  rows.forEach(r => { s[r.status] = Number(r.n); s.Total += Number(r.n); });
  res.json(s);
}));

app.put('/api/admin/complaints/:cid', auth('admin'), wrap(async (req, res) => {
  const { status, remark } = req.body;
  if (!['Pending', 'In Progress', 'Resolved', 'Rejected'].includes(status))
    return res.status(400).json({ error: 'Invalid status' });
  const c = (await q('SELECT id FROM complaints WHERE complaint_id=?', [req.params.cid]))[0];
  if (!c) return res.status(404).json({ error: 'Not found' });
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    await q('UPDATE complaints SET status=? WHERE id=?', [status, c.id], conn);
    await q('INSERT INTO status_history(complaint_id,status,remark) VALUES (?,?,?)', [c.id, status, remark || null], conn);
    await conn.commit();
  } catch (e) { await conn.rollback(); throw e; } finally { conn.release(); }
  res.json({ ok: true });
}));

(async () => {
  try {
    const admin = await q("SELECT 1 AS x FROM users WHERE role='admin'");
    if (!admin[0])
      await q("INSERT INTO users(name,email,password,role) VALUES (?,?,?,'admin')",
        ['City Administrator', 'admin@city.gov', hash('admin123')]);
    const PORT = process.env.PORT || 3000;
    app.listen(PORT, () => console.log(`Smart City Portal API running at http://localhost:${PORT}`));
  } catch (e) {
    console.error('Could not connect to MySQL. Check backend/.env and that you ran schema.sql in MySQL Workbench.\n', e.message);
    process.exit(1);
  }
})();
