-- Smart City Portal : MySQL schema
-- Run in MySQL Workbench: File > Open SQL Script > Execute (lightning bolt)

CREATE DATABASE IF NOT EXISTS smartcity;
USE smartcity;

CREATE TABLE IF NOT EXISTS users (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  name       VARCHAR(100) NOT NULL,
  email      VARCHAR(150) NOT NULL UNIQUE,
  phone      VARCHAR(20),
  password   VARCHAR(200) NOT NULL,
  role       ENUM('citizen','admin') NOT NULL DEFAULT 'citizen',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sessions (
  token      VARCHAR(100) PRIMARY KEY,
  user_id    INT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS categories (
  id   INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS complaints (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  complaint_id VARCHAR(20) UNIQUE,                 -- e.g. SCP-2026-00001 (set by the API after insert)
  user_id      INT NOT NULL,
  category_id  INT NOT NULL,
  title        VARCHAR(200) NOT NULL,
  description  TEXT NOT NULL,
  location     VARCHAR(250) NOT NULL,
  priority     ENUM('Low','Medium','High') NOT NULL DEFAULT 'Medium',
  status       ENUM('Pending','In Progress','Resolved','Rejected') NOT NULL DEFAULT 'Pending',
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (category_id) REFERENCES categories(id),
  INDEX idx_complaints_user (user_id),
  INDEX idx_complaints_status (status)
);

CREATE TABLE IF NOT EXISTS status_history (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  complaint_id INT NOT NULL,
  status       VARCHAR(15) NOT NULL,
  remark       TEXT,
  changed_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (complaint_id) REFERENCES complaints(id) ON DELETE CASCADE
);

-- Trigger: first history entry is created automatically for every new complaint
DROP TRIGGER IF EXISTS trg_complaint_created;
DELIMITER $$
CREATE TRIGGER trg_complaint_created AFTER INSERT ON complaints
FOR EACH ROW
BEGIN
  INSERT INTO status_history(complaint_id, status, remark)
  VALUES (NEW.id, 'Pending', 'Complaint registered');
END$$
DELIMITER ;

-- Seed complaint categories
INSERT IGNORE INTO categories(name) VALUES
 ('Damaged Roads'),('Water Shortage'),('Garbage Overflow'),
 ('Drainage Blockage'),('Streetlight Not Working'),('Other');
