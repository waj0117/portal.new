# Smart City Portal

"Our project aims to bridge the communication gap between citizens and city administrators by
providing a digital platform to report, manage and track civic problems efficiently."

```
smart-city-portal/
├── frontend/            HTML + CSS + JavaScript (user interface)
│   ├── index.html       intro screen (city skyline) -> Enter the portal
│   ├── home.html        welcome, category cards, how it works, track box
│   ├── category.html    one intro page per category (?c=roads, water, ...)
│   ├── track.html       separate Track page
│   ├── portal.html      login, register, new complaint, my complaints, admin
│   ├── css/style.css
│   ├── js/common.js     API address (line 1), category content, menu bar
│   ├── js/portal.js     account / complaint / admin logic
│   └── assets/          logo.svg + icons/ (road, water, garbage, drainage, streetlight, other)
└── backend/             MySQL database + API
    ├── database/
    │   ├── schema.sql   tables, trigger, seed data
    ├── server.js        runs the SQL queries, exposes /api
    └── package.json
```

## Run with MySQL Workbench
1. Open MySQL Workbench, click your local connection (e.g. Local instance MySQL80), enter the root password.
2. File > Open SQL Script > backend/database/schema.sql, then click the lightning bolt to run it.
   This creates the `smartcity` database, tables, trigger and categories.
3. Edit backend/.env: put your MySQL root password in DB_PASSWORD.
4. Backend: cd backend, npm install, npm start  (http://localhost:3000)
5. Frontend: cd frontend, npx serve .  and open the URL (it opens on index.html).
Admin login: admin@city.gov / admin123

View data in Workbench: SCHEMAS panel > smartcity > Tables > hover a table > click the grid icon.
